"use strict";

/* =========================================================
   GAMEFORGE — SINGLE FILE GAME ENGINE
   ---------------------------------------------------------
   This section is intentionally organized so you can replace
   the starter gameplay with your own game.

   MAIN PLACES TO EDIT:
   1. CONFIG        -> speed, colors, difficulty
   2. Player        -> your hero
   3. Enemy         -> enemies
   4. spawnStar()   -> collectibles
   5. update()      -> gameplay rules
   6. draw()        -> visuals
   7. shoot()       -> weapons
   8. levels        -> progression
   ========================================================= */

const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const CONFIG = {
  playerSpeed: 280,
  dashSpeed: 720,
  dashTime: 0.13,
  enemyBaseSpeed: 75,
  enemySpawn: 1.15,
  starValue: 10,
  maxParticles: 700,
  worldColor: "#0a1020"
};

let W=innerWidth,H=innerHeight,DPR=1;
function resize(){
  DPR=Math.min(devicePixelRatio||1,2);
  W=innerWidth; H=innerHeight;
  canvas.width=Math.floor(W*DPR);
  canvas.height=Math.floor(H*DPR);
  canvas.style.width=W+"px"; canvas.style.height=H+"px";
  ctx.setTransform(DPR,0,0,DPR,0,0);
}
addEventListener("resize",resize); resize();

const keys = Object.create(null);
addEventListener("keydown",e=>{
  keys[e.code]=true;
  if(["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(e.code)) e.preventDefault();
});
addEventListener("keyup",e=>keys[e.code]=false);

document.querySelectorAll("[data-key]").forEach(b=>{
  const k=b.dataset.key;
  const on=e=>{e.preventDefault();keys[k]=true};
  const off=e=>{e.preventDefault();keys[k]=false};
  b.addEventListener("pointerdown",on);
  b.addEventListener("pointerup",off);
  b.addEventListener("pointercancel",off);
  b.addEventListener("pointerleave",off);
});

const rand=(a,b)=>a+Math.random()*(b-a);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);

class Particle{
  constructor(x,y,color){
    this.x=x;this.y=y;this.vx=rand(-180,180);this.vy=rand(-180,180);
    this.life=rand(.25,.7);this.max=this.life;this.size=rand(2,6);this.color=color;
  }
  update(dt){this.x+=this.vx*dt;this.y+=this.vy*dt;this.vx*=.97;this.vy*=.97;this.life-=dt}
  draw(){
    ctx.globalAlpha=Math.max(0,this.life/this.max);
    ctx.fillStyle=this.color;ctx.beginPath();ctx.arc(this.x,this.y,this.size,0,Math.PI*2);ctx.fill();
    ctx.globalAlpha=1;
  }
}

class Bullet{
  constructor(x,y,vx,vy){
    this.x=x;this.y=y;this.vx=vx;this.vy=vy;this.life=1.2;this.r=5;
  }
  update(dt){this.x+=this.vx*dt;this.y+=this.vy*dt;this.life-=dt}
  draw(){
    ctx.fillStyle="#fde047";ctx.shadowBlur=14;ctx.shadowColor="#fde047";
    ctx.beginPath();ctx.arc(this.x,this.y,this.r,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
  }
}

class Enemy{
  constructor(){
    const side=Math.floor(Math.random()*4);
    if(side===0){this.x=-30;this.y=rand(0,H)}
    if(side===1){this.x=W+30;this.y=rand(0,H)}
    if(side===2){this.x=rand(0,W);this.y=-30}
    if(side===3){this.x=rand(0,W);this.y=H+30}
    this.r=rand(15,27);
    this.speed=CONFIG.enemyBaseSpeed+game.level*9+rand(-10,25);
    this.hp=1+Math.floor(game.level/5);
  }
  update(dt){
    const a=Math.atan2(player.y-this.y,player.x-this.x);
    this.x+=Math.cos(a)*this.speed*dt;
    this.y+=Math.sin(a)*this.speed*dt;
  }
  draw(){
    ctx.fillStyle="#ef4444";ctx.shadowBlur=18;ctx.shadowColor="#ef4444";
    ctx.beginPath();ctx.arc(this.x,this.y,this.r,0,Math.PI*2);ctx.fill();
    ctx.shadowBlur=0;
    ctx.fillStyle="#7f1d1d";ctx.beginPath();ctx.arc(this.x-5,this.y-4,3,0,7);ctx.fill();
    ctx.beginPath();ctx.arc(this.x+5,this.y-4,3,0,7);ctx.fill();
  }
}

class Star{
  constructor(){
    this.x=rand(45,W-45);this.y=rand(65,H-45);this.r=11;this.t=rand(0,6.28);
  }
  update(dt){this.t+=dt*3}
  draw(){
    const s=1+Math.sin(this.t)*.15;
    ctx.save();ctx.translate(this.x,this.y);ctx.rotate(this.t*.25);ctx.scale(s,s);
    ctx.fillStyle="#facc15";ctx.shadowBlur=18;ctx.shadowColor="#facc15";
    ctx.beginPath();
    for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2?5:12;ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r)}
    ctx.closePath();ctx.fill();ctx.restore();ctx.shadowBlur=0;
  }
}

const player={
  x:W/2,y:H/2,r:18,hp:100,angle:0,shootCd:0,dash:0,
  update(dt){
    let dx=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0);
    let dy=(keys.KeyS||keys.ArrowDown?1:0)-(keys.KeyW||keys.ArrowUp?1:0);
    const len=Math.hypot(dx,dy)||1;
    if(keys.ShiftLeft||keys.ShiftRight) this.dash=CONFIG.dashTime;
    const speed=this.dash>0?CONFIG.dashSpeed:CONFIG.playerSpeed;
    this.x+=dx/len*speed*dt;this.y+=dy/len*speed*dt;
    this.x=clamp(this.x,this.r,W-this.r);this.y=clamp(this.y,this.r+50,H-this.r);
    this.dash=Math.max(0,this.dash-dt);
    this.shootCd-=dt;
    if(keys.Space&&this.shootCd<=0) shoot();
  },
  draw(){
    ctx.save();ctx.translate(this.x,this.y);ctx.rotate(this.angle);
    ctx.fillStyle=this.dash>0?"#a7f3d0":"#22c55e";ctx.shadowBlur=25;ctx.shadowColor="#22c55e";
    ctx.beginPath();ctx.moveTo(23,0);ctx.lineTo(-14,-13);ctx.lineTo(-9,0);ctx.lineTo(-14,13);ctx.closePath();ctx.fill();
    ctx.shadowBlur=0;ctx.fillStyle="#052e16";ctx.beginPath();ctx.arc(-2,0,5,0,Math.PI*2);ctx.fill();
    ctx.restore();
  }
};

let game={
  running:false,score:0,level:1,time:0,spawnTimer:0,
  bullets:[],enemies:[],stars:[],particles:[]
};

function resetGame(){
  game={running:true,score:0,level:1,time:0,spawnTimer:0,bullets:[],enemies:[],stars:[],particles:[]};
  player.x=W/2;player.y=H/2;player.hp=100;player.shootCd=0;player.dash=0;
  for(let i=0;i<5;i++) spawnStar();
  document.getElementById("menu").style.display="none";
}

function spawnStar(){game.stars.push(new Star())}
function burst(x,y,color="#22c55e"){
  for(let i=0;i<18 && game.particles.length<CONFIG.maxParticles;i++)
    game.particles.push(new Particle(x,y,color));
}
function shoot(){
  const dx=Math.cos(player.angle),dy=Math.sin(player.angle);
  game.bullets.push(new Bullet(player.x+dx*20,player.y+dy*20,dx*650,dy*650));
  player.shootCd=.16;
  burst(player.x+dx*22,player.y+dy*22,"#fde047");
}

/* Mouse/touch aiming */
let aimX=W/2,aimY=H/2;
canvas.addEventListener("pointermove",e=>{
  aimX=e.clientX;aimY=e.clientY;
});
canvas.addEventListener("pointerdown",e=>{
  if(e.pointerType==="mouse"){keys.Space=true}
});
canvas.addEventListener("pointerup",e=>{
  if(e.pointerType==="mouse")keys.Space=false;
});

function update(dt){
  if(!game.running)return;
  game.time+=dt;
  player.angle=Math.atan2(aimY-player.y,aimX-player.x);
  player.update(dt);

  game.spawnTimer-=dt;
  const spawnRate=Math.max(.25,CONFIG.enemySpawn-game.level*.045);
  if(game.spawnTimer<=0){
    game.enemies.push(new Enemy());
    game.spawnTimer=spawnRate;
  }

  for(const b of game.bullets)b.update(dt);
  for(const e of game.enemies)e.update(dt);
  for(const s of game.stars)s.update(dt);
  for(const p of game.particles)p.update(dt);

  /* Bullet → enemy collision */
  for(let i=game.bullets.length-1;i>=0;i--){
    const b=game.bullets[i];
    let removed=false;
    for(let j=game.enemies.length-1;j>=0;j--){
      const e=game.enemies[j];
      if(Math.hypot(b.x-e.x,b.y-e.y)<b.r+e.r){
        e.hp--; game.bullets.splice(i,1); removed=true;
        burst(e.x,e.y,"#ef4444");
        if(e.hp<=0){
          game.score+=5;
          game.enemies.splice(j,1);
        }
        break;
      }
    }
    if(!removed&&(b.life<=0||b.x<-50||b.x>W+50||b.y<-50||b.y>H+50))game.bullets.splice(i,1);
  }

  /* Enemy → player */
  for(let i=game.enemies.length-1;i>=0;i--){
    const e=game.enemies[i];
    if(dist(e,player)<e.r+player.r){
      game.enemies.splice(i,1);player.hp-=12;burst(player.x,player.y,"#fb7185");
      if(player.hp<=0){gameOver();return}
    }
  }

  /* Collect stars */
  for(let i=game.stars.length-1;i>=0;i--){
    const s=game.stars[i];
    if(dist(s,player)<s.r+player.r+4){
      game.score+=CONFIG.starValue;burst(s.x,s.y,"#facc15");game.stars.splice(i,1);spawnStar();
    }
  }

  game.level=1+Math.floor(game.score/100);
  game.particles=game.particles.filter(p=>p.life>0);
  document.getElementById("hp").textContent=Math.max(0,Math.ceil(player.hp));
  document.getElementById("score").textContent=game.score;
  document.getElementById("level").textContent=game.level;
}

function gameOver(){
  game.running=false;
  const menu=document.getElementById("menu");
  menu.style.display="flex";
  menu.querySelector("h1").textContent="💥 GAME OVER";
  menu.querySelector("p").innerHTML="Score: <b>"+game.score+"</b><br>Press START to play again.";
  menu.querySelector(".btn").textContent="RESTART";
}

function drawBackground(){
  ctx.fillStyle=CONFIG.worldColor;ctx.fillRect(0,0,W,H);
  ctx.strokeStyle="rgba(255,255,255,.035)";ctx.lineWidth=1;
  const grid=48;
  const ox=(game.time*12)%grid,oy=(game.time*7)%grid;
  for(let x=-grid+ox;x<W+grid;x+=grid){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}
  for(let y=-grid+oy;y<H+grid;y+=grid){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
}

function draw(){
  drawBackground();
  for(const s of game.stars)s.draw();
  for(const b of game.bullets)b.draw();
  for(const e of game.enemies)e.draw();
  for(const p of game.particles)p.draw();
  player.draw();
}

let last=performance.now();
function loop(now){
  const dt=Math.min((now-last)/1000,.033);last=now;
  update(dt);draw();requestAnimationFrame(loop);
}
requestAnimationFrame(loop);

document.getElementById("start").onclick=resetGame;

/* =========================================================
   HOW TO TURN THIS INTO YOUR OWN GAME
   ---------------------------------------------------------
   Example ideas:
   - Replace the triangle player with a sprite/image.
   - Add maps/levels.
   - Add NPCs and bosses.
   - Add coins, inventory and shops.
   - Add sound/music using Web Audio.
   - Add menus and settings.
   - Add touch controls.
   - Save progress with localStorage.
   - Replace the canvas renderer with your own art system.

   QUICK SAVE EXAMPLE:
   localStorage.setItem("myScore", game.score);
   const old = Number(localStorage.getItem("myScore") || 0);

   IMPORTANT:
   This file deliberately has NO external CDN dependency. It can be
   opened directly in a browser and uploaded as index.html to GitHub
   Pages. For a larger commercial game, split CSS/JS/assets into
   separate files later for easier maintenance.
   ========================================================= */
